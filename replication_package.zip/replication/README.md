# Replication package: Leaving X and affective polarization

Code to reproduce every number, table and figure in:

> Khattak, Atif. "Americans Who Left X After Its 2022 Sale Became More Affectively Polarized Than Those Who Stayed: Evidence From a U.S. Panel, 2016–2024." Manuscript submitted to *The International Journal of Press/Politics*.

The analysis compares American National Election Studies (ANES) panel respondents who used Twitter in 2020 and still used X in 2024 (n = 359) with those who had stopped by 2024 (n = 242). Outcomes are affective polarization, confident misperception, anger about the country and trust in news media, measured in 2020 and 2024 (affective polarization also in 2016).

## Quick start

```bash
git clone <this repository>
cd <repository>
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
# put the ANES panel file in data/raw/ (see data/README.md), then:
python run_all.py
```

`run_all.py` runs the five steps below and ends with `All 82 checks passed: results match the manuscript.` The whole run takes under a minute on a laptop.

## What each step produces

| Step | Script | Produces | Used for |
|---|---|---|---|
| 1 | `src/s01_build_data.py` | `output/panel_recoded.csv`, `output/sample_flow.json` | Recoded variables, sample flow, attrition |
| 2 | `src/s02_estimate.py` | `output/analytic_sample.csv`, `output/results.json` | Entropy balancing and every model |
| 3 | `src/s03_tables.py` | `output/tables/table1.*`, `output/tables/table2.*` | Tables 1 and 2 |
| 4 | `src/s04_figures.py` | `output/figures/fig1`–`fig7` (PDF and 600-dpi PNG) | Figures 1–7 |
| 5 | `src/s05_manuscript_numbers.py` | `output/manuscript_numbers.md` | Every number quoted in the text, by section |

`tests/test_reproduction.py` compares a fresh run with `tests/expected.json` (82 checks: sample sizes, all 20 model estimates with standard errors and p-values, the pre-trend test, exit shares and party interactions). It exits with an error and lists any mismatch.

Steps can also be run one at a time from the repository root, for example `python src/s02_estimate.py`. Each step reads only what the previous steps wrote.

## Map from manuscript to output

| In the manuscript | Where to find it |
|---|---|
| Sample flow and exclusions (Data and methods; Figure 1) | `output/sample_flow.json`, first section of `output/manuscript_numbers.md` |
| Share leaving X by party (Figure 2) | `results.json` → `exit_by_party`, `exit_dem_minus_rep` |
| Balance before and after weighting (Table 1; Figure 3) | `output/tables/table1.csv`, `results.json` → `balance` |
| Trajectories 2016–2024 and pre-trend test (Figure 4) | `results.json` → `trajectory`, `pretrend` |
| Individual change (Figure 5) | `results.json` → `raw_change_ap` |
| Main estimates and robustness models (Table 2; Figure 6) | `output/tables/table2.csv`, `results.json` → `estimates`, `primary_full` |
| Party comparison (Figure 7) | `results.json` → `party_split` |

## Methods in brief

- **Groups.** Twitter/X use from the post-election platform items (2020 `V202541b`, 2024 `V242577b`). Stayed = used in both waves; left = used in 2020 only.
- **Weights.** ANES 2024 post-election panel weight `V240106b`. Leavers are additionally reweighted by entropy balancing (Hainmueller 2012) to match stayers on ten 2020 covariates and the four 2020 outcomes.
- **Models.** Weighted least squares, lagged-outcome (primary) and change-score specifications. Standard errors are CR1 cluster-robust on the 101 stratum × PSU units (`V240106d` × `V240106c`), with t tests on 100 degrees of freedom. Holm correction is applied across the four primary tests.
- **Estimators.** Weighted least squares, clustered variance and entropy balancing are implemented in `src/estimators.py` with NumPy and SciPy, so the package has no dependency on statsmodels or R.
- **Randomness.** None in the estimates. The only random step is the jitter in Figure 5, which uses seed `20261009` (`src/config.py`).

Variable names, waves and coding rules are in `codebook/variables.csv`.

## Software

The results were produced with Python 3.13.16, NumPy 2.5.3, pandas 3.0.5, SciPy 1.18.1 and Matplotlib 3.11.2 (pinned in `requirements.txt`). Other recent versions should give the same estimates to at least four decimal places, and the reproduction test allows for that.

Reading the official SPSS file needs `pyreadstat`. The pipeline was verified on a CSV export of the same release; reading the `.sav` file through `pyreadstat` with `apply_value_formats=False` returns the same numeric codes.

## Data availability

The ANES data are not included in this repository. They are freely available from the American National Election Studies after registration, under the ANES terms of use; see `data/README.md`. Respondent-level files derived from them (`output/panel_recoded.csv`, `output/analytic_sample.csv`) are created locally and excluded from version control by `.gitignore`. Aggregate outputs (results, tables, figures) are committed.

## Citation

Please cite the article and the data:

- American National Election Studies. 2026. *ANES 2016–2020–2024 Panel Merged File* [dataset]. Release of 19 May 2026. University of Michigan and Stanford University. www.electionstudies.org.

See `CITATION.cff` for this code.

## License

Code: MIT License (`LICENSE`). The ANES data are governed by the ANES terms of use, not by this license.
