"""Check that a fresh run reproduces the published numbers.

Run after run_all.py (it is called automatically at the end), or directly:
    python tests/test_reproduction.py
Exits with status 1 and lists every mismatch if anything differs.
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
R = json.load(open(ROOT / "output" / "results.json"))
X = json.load(open(ROOT / "tests" / "expected.json"))
TOL = 1e-4  # estimates are deterministic; this only absorbs floating-point noise across platforms
fails = []


def check(name, got, want, tol=TOL):
    if isinstance(want, (int, float)) and isinstance(got, (int, float)):
        ok = abs(got - want) <= tol * max(1.0, abs(want))
    else:
        ok = got == want
    if not ok:
        fails.append(f"{name}: got {got}, expected {want}")


for k, v in X["flow"].items():
    check(f"flow.{k}", R["flow"][k], v, tol=0)
check("analytic_groups", R["flow"]["analytic_groups"], X["analytic_groups"])
est = {f"{e['outcome']}|{e['model']}|{e['weights']}": e for e in R["estimates"]}
for key, want in X["estimates"].items():
    for stat, val in want.items():
        check(f"{key}.{stat}", est[key][stat], val)
for stat, val in X["pretrend"].items():
    check(f"pretrend.{stat}", R["pretrend"][stat], val)
for e in R["exit_by_party"]:
    check(f"exit.{e['party']}", e["share_left"], X["exit_by_party"][e["party"]])
for s in R["party_split"]:
    if s["party"] == "Interaction":
        check(f"interaction_p.{s['outcome']}", s["p"], X["party_interaction_p"][s["outcome"]])
if R["max_abs_smd_after"] > X["max_abs_smd_after_below"]:
    fails.append(f"balance not achieved: max |SMD| = {R['max_abs_smd_after']}")

n = sum(len(v) for v in X["estimates"].values()) + len(X["flow"]) + len(X["pretrend"]) + 9
if fails:
    print("REPRODUCTION FAILED:\n  " + "\n  ".join(fails))
    sys.exit(1)
print(f"All {n} checks passed: results match the manuscript.")
