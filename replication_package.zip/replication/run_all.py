"""Reproduce every number, table and figure in the manuscript.

Usage:  python run_all.py

Runs the five steps in order, then checks the headline results against
tests/expected.json. Takes well under a minute on a laptop.
"""
import runpy
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

STEPS = ["s01_build_data", "s02_estimate", "s03_tables", "s04_figures", "s05_manuscript_numbers"]

for step in STEPS:
    runpy.run_path(str(SRC / f"{step}.py"), run_name="__main__")

print("\nChecking results against tests/expected.json ...")
sys.exit(subprocess.call([sys.executable, str(ROOT / "tests" / "test_reproduction.py")]))
