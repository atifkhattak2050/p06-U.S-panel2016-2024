# Numbers reported in the manuscript

## Data and methods: sample flow

- Panel respondents (2016 respondents re-interviewed in 2020): 2,839
- Completed 2024 post-election interview: 2,070 (retention 72.9%)
- Valid Twitter/X item in both 2020 and 2024: 2,018; groups {'Never': 1251, 'Stayed': 375, 'Left': 254, 'Joined': 138}
- Used Twitter in 2020 (stayed or left): 629
- Excluded for missing outcome or covariate: 28
- Analytic sample: 601 {'Stayed': 359, 'Left': 242}; by party {'Democrat': 335, 'Republican': 220, 'Independent': 46}
- Pre-trend sample (2016 thermometers present): 596
- Retention: Democrats 73.3%, Republicans 73.0%, 2020 Twitter users 80.3%, non-users 76.9%
- Largest |SMD| after entropy balancing: 1.38e-09
- Clusters (stratum x PSU): 101

## Results: who left X (Figure 2)

- Left, unweighted: 254 of 629 (40.4%)
- Democrat: 43% left (148 of 345), 95% CI 36 to 50
- Independent: 42% left (15 of 52), 95% CI 24 to 61
- Republican: 38% left (91 of 232), 95% CI 30 to 47
- Democrat minus Republican: 4.9 points, 95% CI -6.2 to 16.1, z test p = 0.39

## Results: stayers and leavers in 2020 (Table 1, Figure 3)

- age: stayed 41.04, left 44.16, SMD before -0.22, after -5.45e-10
- educ: stayed 4.89, left 4.54, SMD before 0.17, after 1.04e-09
- female: stayed 0.37, left 0.49, SMD before -0.25, after 8.67e-10
- white: stayed 0.67, left 0.64, SMD before 0.08, after -4.51e-10
- pid7: stayed 3.66, left 3.45, SMD before 0.10, after 1.20e-10
- pid_strength: stayed 1.95, left 2.05, SMD before -0.09, after -1.21e-09
- ideo: stayed 3.69, left 3.84, SMD before -0.10, after 7.43e-10
- ideo_missing: stayed 0.07, left 0.19, SMD before -0.36, after -1.02e-09
- attention: stayed 3.78, left 3.82, SMD before -0.03, after 7.31e-10
- facebook: stayed 0.88, left 0.88, SMD before -0.00, after -4.16e-10
- ap20: stayed 50.63, left 48.30, SMD before 0.08, after -5.33e-10
- mis20: stayed -3.51, left -3.18, SMD before -0.16, after 8.38e-10
- ang20: stayed 3.84, left 3.78, SMD before 0.05, after 9.72e-10
- tru20: stayed 2.33, left 2.62, SMD before -0.25, after -1.38e-09

## Results: when the groups diverged (Figure 4)

- Left 2016: 40.1 (95% CI 34.9 to 45.2), n = 250
- Left 2020: 49.7 (95% CI 44.3 to 55.1), n = 250
- Left 2024: 56.4 (95% CI 51.4 to 61.3), n = 250
- Never 2016: 40.5 (95% CI 38.2 to 42.8), n = 1204
- Never 2020: 52.3 (95% CI 49.8 to 54.7), n = 1204
- Never 2024: 53.8 (95% CI 51.5 to 56.2), n = 1204
- Stayed 2016: 40.8 (95% CI 36.9 to 44.8), n = 366
- Stayed 2020: 50.5 (95% CI 46.6 to 54.4), n = 366
- Stayed 2024: 48.7 (95% CI 44.8 to 52.7), n = 366
- Pre-trend placebo: -0.6 points, 95% CI -6.3 to 5.1, p = 0.84, n = 596

## Results: individual change (Figure 5, unweighted)

- Stayed: mean -0.2, median +0, IQR -15 to 15, n = 359
- Left: mean +4.5, median +0, IQR -10 to 20, n = 242

## Results: adjusted estimates (Table 2, Figure 6)

- Weighted AP means: stayed 50.6 -> 49.0; left 48.3 -> 55.5
- Affective polarization | Lagged outcome | Survey + entropy-balancing weights: -8.68 (95% CI -14.42 to -2.95), -0.29 SD, p = 0.003, Holm p = 0.013, SD(2020) = 29.71
- Affective polarization | Change score | Survey + entropy-balancing weights: -8.68 (95% CI -15.35 to -2.02), -0.29 SD, p = 0.011, SD(2020) = 29.71
- Affective polarization | Lagged outcome | Survey weights: -7.91 (95% CI -13.68 to -2.13), -0.27 SD, p = 0.008, SD(2020) = 29.71
- Affective polarization | Change score | Survey weights: -10.09 (95% CI -16.71 to -3.46), -0.34 SD, p = 0.003, SD(2020) = 29.71
- Affective polarization | Lagged outcome | Unweighted: -3.77 (95% CI -7.44 to -0.10), -0.13 SD, p = 0.044, SD(2020) = 29.71
- Confident misperception | Lagged outcome | Survey + entropy-balancing weights: 0.36 (95% CI -0.14 to 0.86), 0.18 SD, p = 0.152, Holm p = 0.455, SD(2020) = 2.04
- Confident misperception | Change score | Survey + entropy-balancing weights: 0.36 (95% CI -0.25 to 0.98), 0.18 SD, p = 0.243, SD(2020) = 2.04
- Confident misperception | Lagged outcome | Survey weights: 0.44 (95% CI -0.03 to 0.91), 0.22 SD, p = 0.064, SD(2020) = 2.04
- Confident misperception | Change score | Survey weights: 0.54 (95% CI -0.10 to 1.17), 0.26 SD, p = 0.096, SD(2020) = 2.04
- Confident misperception | Lagged outcome | Unweighted: 0.47 (95% CI 0.14 to 0.79), 0.23 SD, p = 0.005, SD(2020) = 2.04
- Anger about the country | Lagged outcome | Survey + entropy-balancing weights: 0.14 (95% CI -0.11 to 0.39), 0.12 SD, p = 0.276, Holm p = 0.552, SD(2020) = 1.12
- Anger about the country | Change score | Survey + entropy-balancing weights: 0.14 (95% CI -0.16 to 0.43), 0.12 SD, p = 0.352, SD(2020) = 1.12
- Anger about the country | Lagged outcome | Survey weights: 0.19 (95% CI -0.06 to 0.43), 0.17 SD, p = 0.133, SD(2020) = 1.12
- Anger about the country | Change score | Survey weights: 0.14 (95% CI -0.15 to 0.43), 0.13 SD, p = 0.340, SD(2020) = 1.12
- Anger about the country | Lagged outcome | Unweighted: 0.07 (95% CI -0.12 to 0.26), 0.06 SD, p = 0.476, SD(2020) = 1.12
- Trust in news media | Lagged outcome | Survey + entropy-balancing weights: -0.08 (95% CI -0.26 to 0.09), -0.07 SD, p = 0.365, Holm p = 0.552, SD(2020) = 1.15
- Trust in news media | Change score | Survey + entropy-balancing weights: -0.08 (95% CI -0.28 to 0.12), -0.07 SD, p = 0.437, SD(2020) = 1.15
- Trust in news media | Lagged outcome | Survey weights: -0.12 (95% CI -0.29 to 0.05), -0.10 SD, p = 0.167, SD(2020) = 1.15
- Trust in news media | Change score | Survey weights: 0.01 (95% CI -0.21 to 0.24), 0.01 SD, p = 0.904, SD(2020) = 1.15
- Trust in news media | Lagged outcome | Unweighted: -0.13 (95% CI -0.26 to 0.01), -0.11 SD, p = 0.062, SD(2020) = 1.15

## Results: Democrats and Republicans (Figure 7)

- Affective polarization | Democrat: -0.28 SD (95% CI -0.50 to -0.07), stayed n = 193, left n = 142
- Affective polarization | Republican: -0.19 SD (95% CI -0.44 to 0.07), stayed n = 133, left n = 87
- Affective polarization | stayed x Republican interaction p = 0.51
- Confident misperception | Democrat: -0.05 SD (95% CI -0.31 to 0.21), stayed n = 193, left n = 142
- Confident misperception | Republican: 0.08 SD (95% CI -0.35 to 0.50), stayed n = 133, left n = 87
- Confident misperception | stayed x Republican interaction p = 0.60
- Anger about the country | Democrat: 0.12 SD (95% CI -0.15 to 0.39), stayed n = 193, left n = 142
- Anger about the country | Republican: 0.15 SD (95% CI -0.14 to 0.45), stayed n = 133, left n = 87
- Anger about the country | stayed x Republican interaction p = 0.76
- Trust in news media | Democrat: -0.14 SD (95% CI -0.35 to 0.07), stayed n = 193, left n = 142
- Trust in news media | Republican: 0.02 SD (95% CI -0.23 to 0.26), stayed n = 133, left n = 87
- Trust in news media | stayed x Republican interaction p = 0.27

## Table 2: model fit

- ap: n = 601, clusters = 101, weighted R2 = 0.41
- mis: n = 601, clusters = 101, weighted R2 = 0.33
- ang: n = 601, clusters = 101, weighted R2 = 0.19
- tru: n = 601, clusters = 101, weighted R2 = 0.39
