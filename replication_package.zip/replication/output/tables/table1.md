| Variable | Stayed, mean (SD) | Left, mean (SD) | SMD, survey weights | SMD, balanced |
|---|---|---|---|---|
| Age (years) | 41.04 (13.36) | 44.16 (15.14) | -0.22 | 0.00 |
| Education (1-8) | 4.89 (2.01) | 4.54 (2.09) | 0.17 | 0.00 |
| Female (proportion) | 0.37 (0.48) | 0.49 (0.50) | -0.25 | 0.00 |
| White, non-Hispanic (proportion) | 0.67 (0.47) | 0.64 (0.48) | 0.08 | 0.00 |
| Party ID (1 = strong Dem., 7 = strong Rep.) | 3.66 (2.19) | 3.45 (2.21) | 0.10 | 0.00 |
| Partisan strength (0-3) | 1.95 (1.04) | 2.05 (1.00) | -0.09 | 0.00 |
| Ideology (1 = liberal, 7 = conservative) | 3.69 (1.67) | 3.84 (1.45) | -0.10 | 0.00 |
| Ideology not reported (proportion) | 0.07 (0.26) | 0.19 (0.39) | -0.36 | 0.00 |
| Attention to politics (1-5) | 3.78 (1.03) | 3.82 (0.93) | -0.03 | 0.00 |
| Uses Facebook (proportion) | 0.88 (0.33) | 0.88 (0.32) | 0.00 | 0.00 |
| Affective polarization (0-100), 2020 | 50.63 (28.33) | 48.30 (31.52) | 0.08 | 0.00 |
| Confident misperception (-5 to +5), 2020 | -3.51 (1.92) | -3.18 (2.18) | -0.16 | 0.00 |
| Anger about the country (1-5), 2020 | 3.84 (1.15) | 3.78 (1.08) | 0.05 | 0.00 |
| Trust in news media (1-5), 2020 | 2.33 (1.08) | 2.62 (1.23) | -0.25 | 0.00 |
| Affective polarization (0-100), 2024 | 48.96 (28.57) | 55.46 (29.49) |  |  |
| Confident misperception (-5 to +5), 2024 | -2.86 (2.67) | -3.02 (2.32) |  |  |
| Anger about the country (1-5), 2024 | 3.37 (1.20) | 3.11 (1.18) |  |  |
| Trust in news media (1-5), 2024 | 2.28 (0.97) | 2.56 (1.10) |  |  |
