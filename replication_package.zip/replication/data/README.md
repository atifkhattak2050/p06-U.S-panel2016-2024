# Obtaining the data

This repository does not contain ANES data. To reproduce the results:

1. Go to the ANES Data Center at https://electionstudies.org/data-center/ and register (free).
2. Open the **2016–2020–2024 Panel Merged File** and download the SPSS version.
3. The analysis uses the release dated **19 May 2026** (file name `anes_mergedfile_2016-2020-2024panel_20260519.sav`). Its version stamps are `ANES2016TimeSeries_20190904`, `ANES2020TimeSeries_20220210` and `ANES2024TimeSeries_20260519`. Later releases may revise weights or codes; if so, results can differ slightly, and `tests/test_reproduction.py` will report where.
4. Place the file in this folder:

```
data/raw/anes_mergedfile_2016-2020-2024panel_20260519.sav
```

A CSV export of the same file, named `anes_mergedfile_2016-2020-2024panel_20260519.csv`, also works. If both are present, the `.sav` file is used.

## Checks on the file

A correct file has 2,839 rows (2016 respondents re-interviewed in 2020). Of these, 2,171 completed the 2024 pre-election wave and 2,070 the post-election wave. Step 1 prints the row count, and `output/sample_flow.json` records the counts at each step.

## Terms of use

Use of the ANES data is governed by the ANES terms of use, which you accept when you register. Do not commit the raw file or any respondent-level file derived from it to a public repository. `.gitignore` already excludes them.
