"""Step 2. Analytic sample, entropy balancing and every model in the paper.

Input : output/panel_recoded.csv, output/sample_flow.json
Output: output/analytic_sample.csv   601 stayers/leavers with final weights
        output/results.json          all estimates used in text, tables, figures
"""
import json

import numpy as np
import pandas as pd
from scipy import stats

from config import COV, OUT, OUTCOMES
from estimators import ebal, holm, kish_neff, wls, wmean, wsd

d = pd.read_csv(OUT / "panel_recoded.csv")
flow = json.load(open(OUT / "sample_flow.json"))
R = {"flow": flow}


def tinterval(b, se, G):
    tc = stats.t.ppf(0.975, G - 1)
    return b - tc * se, b + tc * se, float(2 * stats.t.sf(abs(b / se), G - 1))


# Analytic sample -------------------------------------------------------------
users = d[d["group"].isin(["Stayed", "Left"])].copy()
need = COV + [f"{k}{y}" for k in OUTCOMES for y in ("20", "24")] + ["w24", "cluster"]
an = users.dropna(subset=need).copy()
an["stayed"] = (an["group"] == "Stayed").astype(float)
flow["twitter_users_2020_stayed_or_left"] = int(len(users))
flow["excluded_missing"] = int(len(users) - len(an))
flow["analytic_n"] = int(len(an))
flow["analytic_groups"] = {k: int(v) for k, v in an["group"].value_counts().items()}
flow["analytic_party"] = {k: int(v) for k, v in an["party"].value_counts().items()}

# Entropy balancing: reweight leavers to stayers' weighted 2020 means (ATT) --
BAL = COV + [f"{k}20" for k in OUTCOMES]
T, C = an[an.stayed == 1], an[an.stayed == 0]
target = np.average(T[BAL].values, axis=0, weights=T["w24"].values)
eb, success = ebal(C[BAL].values, target, C["w24"].values)
an["eb"] = an["w24"]
an.loc[an.stayed == 0, "eb"] = eb / eb.sum() * C["w24"].sum()
R["ebal_optimizer_success_flag"] = success

BAL_LABEL = {"age": "Age", "educ": "Education", "female": "Female", "white": "White, non-Hispanic",
             "pid7": "Party ID (1 = strong Dem., 7 = strong Rep.)", "pid_strength": "Partisan strength",
             "ideo": "Ideology (1 = liberal, 7 = conservative)", "ideo_missing": "Ideology not reported",
             "attention": "Attention to politics", "facebook": "Uses Facebook", "ap20": "Affective polarization, 2020",
             "mis20": "Confident misperception, 2020", "ang20": "Anger, 2020", "tru20": "Trust in news media, 2020"}
bal = []
for v in BAL:
    xt, xc = T[v].values, C[v].values
    sdp = np.sqrt((wsd(xt, T["w24"].values) ** 2 + wsd(xc, C["w24"].values) ** 2) / 2)
    bal.append({
        "var": v, "label": BAL_LABEL[v],
        "mean_stayed": wmean(xt, T["w24"].values), "sd_stayed": wsd(xt, T["w24"].values),
        "mean_left": wmean(xc, C["w24"].values), "sd_left": wsd(xc, C["w24"].values),
        "smd_before": (wmean(xt, T["w24"].values) - wmean(xc, C["w24"].values)) / sdp,
        "smd_after": (wmean(xt, T["w24"].values) - wmean(xc, an.loc[an.stayed == 0, "eb"].values)) / sdp,
    })
R["balance"] = bal
R["max_abs_smd_after"] = max(abs(b["smd_after"]) for b in bal)

# Weighted outcome means by group (survey weights) ---------------------------
R["group_means"] = {g: {f"{k}{y}": wmean(an.loc[an.group == g, f"{k}{y}"].values, an.loc[an.group == g, "w24"].values)
                        for k in OUTCOMES for y in ("20", "24")} for g in ["Stayed", "Left"]}

# Main models -------------------------------------------------------------------
X = an[COV].values
specs = [("Lagged outcome", "Survey + entropy-balancing weights"), ("Change score", "Survey + entropy-balancing weights"),
         ("Lagged outcome", "Survey weights"), ("Change score", "Survey weights"), ("Lagged outcome", "Unweighted")]
est = []
for k, lab in OUTCOMES.items():
    y20, y24 = an[f"{k}20"].values, an[f"{k}24"].values
    sd20 = wsd(y20, an["w24"].values)
    for model, wname in specs:
        w = {"Survey weights": an["w24"].values, "Survey + entropy-balancing weights": an["eb"].values,
             "Unweighted": np.ones(len(an))}[wname]
        if model == "Lagged outcome":
            b, se, G, r2 = wls(y24, np.column_stack([an.stayed.values, y20, X]), w, an.cluster.values)
        else:
            b, se, G, r2 = wls(y24 - y20, np.column_stack([an.stayed.values, X]), w, an.cluster.values)
        lo, hi, p = tinterval(b[1], se[1], G)
        est.append({"outcome": k, "label": lab, "model": model, "weights": wname, "b": b[1], "se": se[1], "lo": lo, "hi": hi,
                    "p": p, "sd20": sd20, "b_std": b[1] / sd20, "lo_std": lo / sd20, "hi_std": hi / sd20,
                    "n": int(len(an)), "clusters": int(G), "r2": r2})
prim = [e for e in est if e["model"] == "Lagged outcome" and e["weights"].startswith("Survey +")]
for e, ph in zip(prim, holm([e["p"] for e in prim])):
    e["p_holm"] = float(ph)
R["estimates"] = est

# Full coefficient table for the primary models (Table 2) ---------------------
full = {}
names = ["const", "stayed", "outcome_2020"] + COV
for k in OUTCOMES:
    b, se, G, r2 = wls(an[f"{k}24"].values, np.column_stack([an.stayed.values, an[f"{k}20"].values, X]),
                       an["eb"].values, an.cluster.values)
    p = 2 * stats.t.sf(np.abs(b / se), G - 1)
    full[k] = {"coef": dict(zip(names, map(float, b))), "se": dict(zip(names, map(float, se))),
               "p": dict(zip(names, map(float, p))), "n": int(len(an)), "clusters": int(G), "r2": float(r2)}
R["primary_full"] = full

# Pre-trend placebo: 2020 polarization on staying, controlling 2016 ----------
pt = an.dropna(subset=["ap16"])
b, se, G, _ = wls(pt["ap20"].values, np.column_stack([pt.stayed.values, pt["ap16"].values, pt[COV].values]),
                  pt["eb"].values, pt.cluster.values)
lo, hi, p = tinterval(b[1], se[1], G)
R["pretrend"] = {"b": b[1], "se": se[1], "lo": lo, "hi": hi, "p": p, "n": int(len(pt))}

# Affective polarization trajectories, 2016-2024 (Figure 4) -----------------
traj = []
tr = d[d["group"].isin(["Stayed", "Left", "Never"])].dropna(subset=["ap16", "ap20", "ap24", "w24"])
for g, gd in tr.groupby("group"):
    w = gd["w24"].values
    for yr in ("16", "20", "24"):
        mu, se = wmean(gd[f"ap{yr}"].values, w), wsd(gd[f"ap{yr}"].values, w) / np.sqrt(kish_neff(w))
        traj.append({"group": g, "year": 2000 + int(yr), "mean": mu, "lo": mu - 1.96 * se, "hi": mu + 1.96 * se, "n": int(len(gd))})
R["trajectory"] = traj

# Exit by party (Figure 2) and Democrat-Republican difference --------------
u = users[users["party"].ne("") & users["party"].notna() & users["w24"].notna()]
ex = []
for pn, gd in u.groupby("party"):
    left = (gd["group"] == "Left").astype(float).values
    w = gd["w24"].values
    p_ = wmean(left, w)
    se = np.sqrt(p_ * (1 - p_) / kish_neff(w))
    ex.append({"party": pn, "share_left": p_, "se": se, "lo": p_ - 1.96 * se, "hi": p_ + 1.96 * se,
               "n": int(len(gd)), "n_left": int(left.sum())})
R["exit_by_party"] = ex
dem, rep = [next(e for e in ex if e["party"] == x) for x in ("Democrat", "Republican")]
diff, sed = dem["share_left"] - rep["share_left"], np.hypot(dem["se"], rep["se"])
R["exit_dem_minus_rep"] = {"diff": diff, "lo": diff - 1.96 * sed, "hi": diff + 1.96 * sed,
                           "p": float(2 * stats.norm.sf(abs(diff / sed)))}
R["exit_overall_unweighted"] = {"n_left": int((users.group == "Left").sum()), "n": int(len(users))}

# Party split (Figure 7): separate models + pooled interaction ----------------
ps = an[an["party"].isin(["Democrat", "Republican"])]
cov_within = [c for c in COV if c != "pid_strength"]  # strength = |pid7 - 4| is collinear with pid7 within a party
split = []
for k, lab in OUTCOMES.items():
    sd20 = wsd(an[f"{k}20"].values, an["w24"].values)
    for pn in ("Democrat", "Republican"):
        g_ = ps[ps.party == pn]
        b, se, G, _ = wls(g_[f"{k}24"].values, np.column_stack([g_.stayed.values, g_[f"{k}20"].values, g_[cov_within].values]),
                          g_["eb"].values, g_.cluster.values)
        lo, hi, p = tinterval(b[1], se[1], G)
        split.append({"outcome": k, "label": lab, "party": pn, "b": b[1], "p": p, "b_std": b[1] / sd20, "lo_std": lo / sd20,
                      "hi_std": hi / sd20, "n_stayed": int(g_.stayed.sum()), "n_left": int((1 - g_.stayed).sum())})
    Xi = np.column_stack([ps.stayed.values, ps.republican.values, ps.stayed.values * ps.republican.values,
                          ps[f"{k}20"].values, ps[COV].values])
    b, se, G, _ = wls(ps[f"{k}24"].values, Xi, ps["eb"].values, ps.cluster.values)
    split.append({"outcome": k, "label": lab, "party": "Interaction", "b": b[3], "b_std": b[3] / sd20,
                  "p": float(2 * stats.t.sf(abs(b[3] / se[3]), G - 1))})
R["party_split"] = split

# Raw (unweighted) change in affective polarization (Figure 5) --------------
R["raw_change_ap"] = {}
for g in ("Stayed", "Left"):
    ch = (an.loc[an.group == g, "ap24"] - an.loc[an.group == g, "ap20"]).values
    q1, med, q3 = np.percentile(ch, [25, 50, 75])
    R["raw_change_ap"][g] = {"mean": float(ch.mean()), "median": float(med), "q1": float(q1), "q3": float(q3), "n": int(len(ch))}

an.to_csv(OUT / "analytic_sample.csv", index=False)
with open(OUT / "results.json", "w") as fh:
    json.dump(R, fh, indent=1, default=float)
pm = next(e for e in prim if e["outcome"] == "ap")
print(f"[s02] n = {len(an)}; affective polarization b = {pm['b']:.2f} [{pm['lo']:.2f}, {pm['hi']:.2f}], Holm p = {pm['p_holm']:.3f}")
