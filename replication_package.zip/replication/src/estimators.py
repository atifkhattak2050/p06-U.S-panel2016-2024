"""Estimators written for this study (no statsmodels dependency).

wls      weighted least squares with CR1 cluster-robust standard errors
ebal     entropy balancing (Hainmueller 2012), solved on the dual with BFGS
wmean    weighted mean
wsd      weighted standard deviation (population form)
holm     Holm (1979) step-down adjusted p-values
"""
import numpy as np
import pandas as pd
from scipy.optimize import minimize


def wls(y, X, w, cluster):
    """Weighted least squares with CR1 cluster-robust variance.

    Returns (coefficients incl. constant first, standard errors, number of
    clusters, weighted R-squared). Weights are normalised to mean 1, which
    leaves the point estimates and the CR1 variance unchanged.
    """
    X = np.column_stack([np.ones(len(y)), X])
    W = w / w.mean()
    XtW = X.T * W
    bread = np.linalg.inv(XtW @ X)
    beta = bread @ (XtW @ y)
    u = y - X @ beta
    k = X.shape[1]
    meat = np.zeros((k, k))
    groups = pd.unique(cluster)
    for g in groups:
        m = cluster == g
        s = (X[m] * (W[m] * u[m])[:, None]).sum(0)
        meat += np.outer(s, s)
    n, G = X.shape[0], len(groups)
    adj = G / (G - 1) * (n - 1) / (n - k)
    V = adj * bread @ meat @ bread
    ybar = np.sum(W * y) / W.sum()
    r2 = 1 - np.sum(W * u ** 2) / np.sum(W * (y - ybar) ** 2)
    return beta, np.sqrt(np.diag(V)), G, r2


def ebal(Xc, target_means, base_weights):
    """Entropy balancing weights for the control group.

    Finds weights proportional to base_weights * exp(Z @ lambda) whose
    weighted means of Xc equal target_means. Covariates are standardised
    before optimisation for numerical stability. Returns weights scaled to
    sum to len(Xc) and the optimizer's success flag (BFGS can report
    'precision loss' even when balance is exact; check balance directly).
    """
    Z = Xc - target_means
    sd = Z.std(0)
    sd[sd == 0] = 1
    Z = Z / sd
    q = base_weights / base_weights.sum()

    def dual(lam):
        e = q * np.exp(Z @ lam)
        return np.log(e.sum()), (Z * e[:, None]).sum(0) / e.sum()

    res = minimize(lambda l: dual(l)[0], np.zeros(Z.shape[1]), jac=lambda l: dual(l)[1],
                   method="BFGS", options={"gtol": 1e-10, "maxiter": 2000})
    w = q * np.exp(Z @ res.x)
    return w / w.sum() * len(w), bool(res.success)


def wmean(x, w):
    return float(np.sum(w * x) / np.sum(w))


def wsd(x, w):
    m = wmean(x, w)
    return float(np.sqrt(np.sum(w * (x - m) ** 2) / np.sum(w)))


def kish_neff(w):
    return float(w.sum() ** 2 / (w ** 2).sum())


def holm(pvals):
    """Holm step-down adjusted p-values, returned in the input order."""
    p = np.asarray(pvals, dtype=float)
    order = np.argsort(p)
    m = len(p)
    adj = np.empty(m)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, min(1.0, (m - rank) * p[i]))
        adj[i] = running
    return adj
