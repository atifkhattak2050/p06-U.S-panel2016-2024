"""Step 3. Table 1 and Table 2 as CSV and Markdown.

Input : output/results.json
Output: output/tables/table1.{csv,md}, output/tables/table2.{csv,md}
"""
import json

import pandas as pd

from config import COV, OUT, OUTCOMES, TAB_DIR
from estimators import wmean, wsd

R = json.load(open(OUT / "results.json"))
TAB_DIR.mkdir(parents=True, exist_ok=True)

LAB = {"age": "Age (years)", "educ": "Education (1-8)", "female": "Female (proportion)",
       "white": "White, non-Hispanic (proportion)", "pid7": "Party ID (1 = strong Dem., 7 = strong Rep.)",
       "pid_strength": "Partisan strength (0-3)", "ideo": "Ideology (1 = liberal, 7 = conservative)",
       "ideo_missing": "Ideology not reported (proportion)", "attention": "Attention to politics (1-5)",
       "facebook": "Uses Facebook (proportion)", "ap": "Affective polarization (0-100)",
       "mis": "Confident misperception (-5 to +5)", "ang": "Anger about the country (1-5)", "tru": "Trust in news media (1-5)"}


def f2(x):
    s = f"{x:.2f}"
    return "0.00" if s == "-0.00" else s


def to_md(df, index=False):
    cols = ([df.index.name or ""] if index else []) + list(df.columns)
    lines = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    for i, row in df.iterrows():
        cells = ([str(i)] if index else []) + [str(v) for v in row]
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


# Table 1 -------------------------------------------------------------------------
bal = {b["var"]: b for b in R["balance"]}
gm = R["group_means"]
rows = []
for v in COV + [f"{k}20" for k in OUTCOMES]:
    b = bal[v]
    lab = LAB[v] if v in LAB else f"{LAB[v[:-2]]}, 2020"
    rows.append([lab, f"{f2(b['mean_stayed'])} ({f2(b['sd_stayed'])})", f"{f2(b['mean_left'])} ({f2(b['sd_left'])})",
                 f2(b["smd_before"]), f2(b["smd_after"])])
# 2024 outcomes: weighted means and SDs come from the analytic sample
an = pd.read_csv(OUT / "analytic_sample.csv")
for k in OUTCOMES:
    cells = []
    for g in ("Stayed", "Left"):
        s = an[an.group == g]
        cells.append(f"{f2(wmean(s[f'{k}24'].values, s.w24.values))} ({f2(wsd(s[f'{k}24'].values, s.w24.values))})")
    rows.append([f"{LAB[k]}, 2024", *cells, "", ""])
t1 = pd.DataFrame(rows, columns=["Variable", "Stayed, mean (SD)", "Left, mean (SD)", "SMD, survey weights", "SMD, balanced"])
t1.to_csv(TAB_DIR / "table1.csv", index=False)
(TAB_DIR / "table1.md").write_text(to_md(t1))


# Table 2 -------------------------------------------------------------------------
def stars(p):
    return "***" if p < .001 else "**" if p < .01 else "*" if p < .05 else ""


rowname = {"stayed": "Stayed on X (vs left)", "outcome_2020": "Outcome in 2020", "const": "Constant",
           **{c: LAB[c].replace(" (proportion)", "") for c in COV}}
order = ["stayed", "outcome_2020"] + COV + ["const"]
t2 = pd.DataFrame(index=[rowname[r] for r in order])
for k in OUTCOMES:
    m = R["primary_full"][k]
    col = [f"{f2(m['coef'][r])}{stars(m['p'][r])} ({f2(m['se'][r])})" for r in order]
    t2[LAB[k]] = col
fit = pd.DataFrame({LAB[k]: [str(R["primary_full"][k]["n"]), str(R["primary_full"][k]["clusters"]),
                             f2(R["primary_full"][k]["r2"])] for k in OUTCOMES}, index=["N", "Clusters", "Weighted R2"])
t2 = pd.concat([t2, fit])
t2.index.name = "Term"
t2.to_csv(TAB_DIR / "table2.csv")
(TAB_DIR / "table2.md").write_text(to_md(t2, index=True))
print("[s03] wrote Table 1 and Table 2")
