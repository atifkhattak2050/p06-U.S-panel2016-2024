"""Step 1. Read the ANES panel file and build analysis variables.

Input : data/raw/anes_mergedfile_2016-2020-2024panel_20260519.sav (or .csv)
Output: output/panel_recoded.csv     all 2,839 panel respondents, recoded
        output/sample_flow.json      counts at each exclusion step

Coding rules (see codebook/variables.csv):
- All negative ANES codes (refused, don't know, inapplicable, no interview)
  are set to missing. Thermometers outside 0-100 are missing.
- Ideology answers outside 1-7 ("haven't thought much", refused) are set
  to 4 and flagged with ideo_missing = 1.
"""
import json

import numpy as np
import pandas as pd

from config import OUT, RAW_CANDIDATES


def read_raw():
    for p in RAW_CANDIDATES:
        if p.exists():
            if p.suffix == ".sav":
                import pyreadstat  # pip install pyreadstat
                df, _ = pyreadstat.read_sav(str(p), apply_value_formats=False)
                return df, p
            return pd.read_csv(p, low_memory=False), p
    raise FileNotFoundError(
        "ANES panel file not found. Download it from electionstudies.org and place it in data/raw/ "
        "(see data/README.md). Expected one of: " + ", ".join(str(p.name) for p in RAW_CANDIDATES))


raw, path = read_raw()


def num(v):
    """Column as numbers; blanks and non-numeric values become missing."""
    return pd.to_numeric(raw[v].astype(str).str.strip().replace({"": np.nan, "nan": np.nan}), errors="coerce")


def rng(v, lo, hi):
    s = num(v)
    return s.where(s.between(lo, hi))


d = pd.DataFrame({"caseid_2016": num("V160001")})

# Exposure: Twitter/X visited, 2020 and 2024 post-election waves -------------
tw20, tw24 = num("V202541b"), num("V242577b")
valid_x = tw20.isin([0, 1]) & tw24.isin([0, 1])
d["group"] = np.select(
    [(tw20 == 1) & (tw24 == 1), (tw20 == 1) & (tw24 == 0), (tw20 == 0) & (tw24 == 1), (tw20 == 0) & (tw24 == 0)],
    ["Stayed", "Left", "Joined", "Never"], "")
d.loc[~valid_x, "group"] = ""

# Party (2020 seven-point identification; leaners count as partisans) -------
pid = rng("V201231x", 1, 7)
d["pid7"] = pid
d["party"] = np.select([pid.between(1, 3), pid == 4, pid.between(5, 7)], ["Democrat", "Independent", "Republican"], "")
d["pid_strength"] = (pid - 4).abs()
d["republican"] = (pid >= 5).astype(float).where(pid.notna())


# Outcomes -------------------------------------------------------------------
def affective_polarization(dem, rep):
    return (rng(dem, 0, 100) - rng(rep, 0, 100)).abs()


d["ap16"] = affective_polarization("V161095", "V161096")
d["ap20"] = affective_polarization("V201156", "V201157")
d["ap24"] = affective_polarization("V241166", "V241167")


def confident_misperception(belief, confidence):
    """+1..+5 if the respondent says vaccines cause autism, -1..-5 if not, scaled by confidence."""
    b, c = rng(belief, 1, 2), rng(confidence, 1, 5)
    return pd.Series(np.where(b == 1, c, np.where(b == 2, -c, np.nan)), index=raw.index)


d["mis20"] = confident_misperception("V202553", "V202554")
d["mis24"] = confident_misperception("V242563", "V242564")
d["ang20"], d["ang24"] = rng("V201118", 1, 5), rng("V241121", 1, 5)
d["tru20"], d["tru24"] = rng("V201377", 1, 5), rng("V241335", 1, 5)

# 2020 covariates -------------------------------------------------------------
d["age"] = rng("V201507x", 18, 80)
d["educ"] = rng("V201510", 1, 8)
gender = num("V201600")
d["female"] = (gender == 2).astype(float).where(gender.isin([1, 2]))
race = num("V201549x")
d["white"] = (race == 1).astype(float).where(race.between(1, 6))
ideo = rng("V201200", 1, 7)
d["ideo_missing"] = ideo.isna().astype(float)
d["ideo"] = ideo.fillna(4)
d["attention"] = 6 - rng("V201005", 1, 5)  # reversed: 5 = always pays attention
fb = num("V202541a")
d["facebook"] = fb.where(fb.isin([0, 1]))
d["x_freq24"] = rng("V242580", 1, 7)  # 1 = many times a day ... 7 = less than monthly

# Design ----------------------------------------------------------------------
d["w24"] = num("V240106b")                              # 2024 post-election panel weight
d["cluster"] = num("V240106d") * 10 + num("V240106c")   # stratum x PSU
post24 = num("V240002b") == 2                           # completed 2024 post-election interview
d["post24"] = post24.astype(int)
tw20_user = tw20 == 1
tw20_valid = tw20.isin([0, 1])

flow = {
    "source_file": path.name,
    "panel_2020": int(len(d)),
    "interviewed_2024_post": int(post24.sum()),
    "valid_x_both_waves": int(valid_x.sum()),
    "groups_valid_x": {k: int(v) for k, v in d.loc[valid_x, "group"].value_counts().items()},
    "retention_2024_post": {
        "overall": float(post24.mean()),
        "Democrat": float(post24[d.party == "Democrat"].mean()),
        "Republican": float(post24[d.party == "Republican"].mean()),
        "twitter_user_2020": float(post24[tw20_valid & tw20_user].mean()),
        "twitter_nonuser_2020": float(post24[tw20_valid & ~tw20_user].mean()),
    },
}

OUT.mkdir(parents=True, exist_ok=True)
d.to_csv(OUT / "panel_recoded.csv", index=False)
with open(OUT / "sample_flow.json", "w") as fh:
    json.dump(flow, fh, indent=1)
print(f"[s01] read {path.name}: {len(d)} respondents; {int(valid_x.sum())} with valid X use in both waves")
