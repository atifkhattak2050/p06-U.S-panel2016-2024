"""Paths and constants shared by every script."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = ROOT / "data" / "raw"
OUT = ROOT / "output"
FIG_DIR = OUT / "figures"
TAB_DIR = OUT / "tables"

# The ANES file is not redistributed here. Place the official SPSS release
# (or a CSV export of it) in data/raw/ under one of these names.
RAW_CANDIDATES = [
    RAW_DIR / "anes_mergedfile_2016-2020-2024panel_20260519.sav",
    RAW_DIR / "anes_mergedfile_2016-2020-2024panel_20260519.csv",
]

# 2020 covariates entered in every model (see codebook/variables.csv)
COV = ["age", "educ", "female", "white", "pid7", "pid_strength", "ideo", "ideo_missing", "attention", "facebook"]

# Outcomes: prefix -> label. Each has a 2020 ("20") and 2024 ("24") column.
OUTCOMES = {
    "ap": "Affective polarization",
    "mis": "Confident misperception",
    "ang": "Anger about the country",
    "tru": "Trust in news media",
}

SEED = 20261009  # used only for horizontal jitter in Figure 5
