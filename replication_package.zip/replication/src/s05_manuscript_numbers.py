"""Step 5. Every number quoted in the manuscript, in reading order.

Input : output/results.json
Output: output/manuscript_numbers.md

Each line names the manuscript section and gives the value as computed, so
any number in the paper can be traced to this file and then to the code.
"""
import json

from config import OUT

R = json.load(open(OUT / "results.json"))
F = R["flow"]
E = {(e["outcome"], e["model"], e["weights"]): e for e in R["estimates"]}
P = "Survey + entropy-balancing weights"
L = []


def h(title):
    L.append(f"\n## {title}\n")


def line(text):
    L.append(f"- {text}")


def ci(lo, hi, d=1):
    return f"95% CI {lo:.{d}f} to {hi:.{d}f}"


h("Data and methods: sample flow")
line(f"Panel respondents (2016 respondents re-interviewed in 2020): {F['panel_2020']:,}")
line(f"Completed 2024 post-election interview: {F['interviewed_2024_post']:,} "
     f"(retention {F['retention_2024_post']['overall']*100:.1f}%)")
line(f"Valid Twitter/X item in both 2020 and 2024: {F['valid_x_both_waves']:,}; groups {F['groups_valid_x']}")
line(f"Used Twitter in 2020 (stayed or left): {F['twitter_users_2020_stayed_or_left']}")
line(f"Excluded for missing outcome or covariate: {F['excluded_missing']}")
line(f"Analytic sample: {F['analytic_n']} {F['analytic_groups']}; by party {F['analytic_party']}")
line(f"Pre-trend sample (2016 thermometers present): {R['pretrend']['n']}")
rt = F["retention_2024_post"]
line(f"Retention: Democrats {rt['Democrat']*100:.1f}%, Republicans {rt['Republican']*100:.1f}%, "
     f"2020 Twitter users {rt['twitter_user_2020']*100:.1f}%, non-users {rt['twitter_nonuser_2020']*100:.1f}%")
line(f"Largest |SMD| after entropy balancing: {R['max_abs_smd_after']:.2e}")
line(f"Clusters (stratum x PSU): {E[('ap', 'Lagged outcome', P)]['clusters']}")

h("Results: who left X (Figure 2)")
eo = R["exit_overall_unweighted"]
line(f"Left, unweighted: {eo['n_left']} of {eo['n']} ({eo['n_left']/eo['n']*100:.1f}%)")
for e in R["exit_by_party"]:
    line(f"{e['party']}: {e['share_left']*100:.0f}% left ({e['n_left']} of {e['n']}), {ci(e['lo']*100, e['hi']*100, 0)}")
dr = R["exit_dem_minus_rep"]
line(f"Democrat minus Republican: {dr['diff']*100:.1f} points, {ci(dr['lo']*100, dr['hi']*100)}, z test p = {dr['p']:.2f}")

h("Results: stayers and leavers in 2020 (Table 1, Figure 3)")
for b in R["balance"]:
    line(f"{b['var']}: stayed {b['mean_stayed']:.2f}, left {b['mean_left']:.2f}, "
         f"SMD before {b['smd_before']:.2f}, after {b['smd_after']:.2e}")

h("Results: when the groups diverged (Figure 4)")
for t in R["trajectory"]:
    line(f"{t['group']} {t['year']}: {t['mean']:.1f} ({ci(t['lo'], t['hi'])}), n = {t['n']}")
pt = R["pretrend"]
line(f"Pre-trend placebo: {pt['b']:.1f} points, {ci(pt['lo'], pt['hi'])}, p = {pt['p']:.2f}, n = {pt['n']}")

h("Results: individual change (Figure 5, unweighted)")
for g, v in R["raw_change_ap"].items():
    line(f"{g}: mean {v['mean']:+.1f}, median {v['median']:+.0f}, IQR {v['q1']:.0f} to {v['q3']:.0f}, n = {v['n']}")

h("Results: adjusted estimates (Table 2, Figure 6)")
gm = R["group_means"]
line(f"Weighted AP means: stayed {gm['Stayed']['ap20']:.1f} -> {gm['Stayed']['ap24']:.1f}; "
     f"left {gm['Left']['ap20']:.1f} -> {gm['Left']['ap24']:.1f}")
for k in ["ap", "mis", "ang", "tru"]:
    for model, w in [("Lagged outcome", P), ("Change score", P), ("Lagged outcome", "Survey weights"),
                     ("Change score", "Survey weights"), ("Lagged outcome", "Unweighted")]:
        e = E[(k, model, w)]
        extra = f", Holm p = {e['p_holm']:.3f}" if "p_holm" in e else ""
        line(f"{e['label']} | {model} | {w}: {e['b']:.2f} ({ci(e['lo'], e['hi'], 2)}), "
             f"{e['b_std']:.2f} SD, p = {e['p']:.3f}{extra}, SD(2020) = {e['sd20']:.2f}")

h("Results: Democrats and Republicans (Figure 7)")
for s in R["party_split"]:
    if s["party"] == "Interaction":
        line(f"{s['label']} | stayed x Republican interaction p = {s['p']:.2f}")
    else:
        line(f"{s['label']} | {s['party']}: {s['b_std']:.2f} SD ({ci(s['lo_std'], s['hi_std'], 2)}), "
             f"stayed n = {s['n_stayed']}, left n = {s['n_left']}")

h("Table 2: model fit")
for k, m in R["primary_full"].items():
    line(f"{k}: n = {m['n']}, clusters = {m['clusters']}, weighted R2 = {m['r2']:.2f}")

(OUT / "manuscript_numbers.md").write_text("# Numbers reported in the manuscript\n" + "\n".join(L) + "\n")
print("[s05] wrote output/manuscript_numbers.md")
