"""Step 4. The seven manuscript figures.

Input : output/results.json, output/analytic_sample.csv
Output: output/figures/fig1..fig7 as vector PDF and 600-dpi PNG

Okabe-Ito colours plus marker shape, so figures read in grayscale.
Figures are drawn at 6.5 in wide with 7-8.5 pt text.
"""
import json

import matplotlib as mpl

mpl.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np
import pandas as pd
from matplotlib.patches import FancyBboxPatch

from config import FIG_DIR, OUT, SEED

R = json.load(open(OUT / "results.json"))
A = pd.read_csv(OUT / "analytic_sample.csv")
FIG_DIR.mkdir(parents=True, exist_ok=True)

mpl.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9, "axes.labelsize": 8.5,
    "xtick.labelsize": 8, "ytick.labelsize": 8, "legend.fontsize": 8, "axes.spines.top": False,
    "axes.spines.right": False, "axes.linewidth": 0.7, "xtick.major.width": 0.7, "ytick.major.width": 0.7,
    "pdf.fonttype": 42, "savefig.bbox": "tight", "savefig.pad_inches": 0.04,
})
BLUE, VERM, GREY, BLACK = "#0072B2", "#D55E00", "#7F7F7F", "#222222"
COL = {"Stayed": BLUE, "Left": VERM, "Never": GREY}
MRK = {"Stayed": "o", "Left": "s", "Never": "^"}
W = 6.5


def save(fig, name):
    fig.savefig(FIG_DIR / f"{name}.pdf", metadata={"CreationDate": None, "ModDate": None})
    fig.savefig(FIG_DIR / f"{name}.png", dpi=600)
    plt.close(fig)


# Figure 1: design and sample flow ---------------------------------------
fl = R["flow"]
fig, ax = plt.subplots(figsize=(W, 3.6))
ax.set_xlim(0, 100)
ax.set_ylim(0, 62)
ax.axis("off")


def box(x, y, w, h, text, ec=BLACK, fc="white", bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.25,rounding_size=1.2", ec=ec, fc=fc, lw=0.8))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=7.3, fontweight="bold" if bold else "normal", linespacing=1.3)


def arrow(x1, y1, x2, y2):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="-|>", lw=0.8, color=BLACK, mutation_scale=8))


# timeline
for x, lab in [(8, "2016\nwave"), (34, "2020\nwave"), (60, "Oct 2022\nTwitter sold,\nrenamed X"), (86, "2024\nwave")]:
    ax.plot([x], [56], marker="D" if "Oct" in lab else "o", ms=6 if "Oct" in lab else 5, color=VERM if "Oct" in lab else BLACK)
    ax.text(x, 52.6, lab, ha="center", va="top", fontsize=7.5, color=VERM if "Oct" in lab else BLACK)
ax.plot([8, 86], [56, 56], color=BLACK, lw=0.8, zorder=0)
box(0.5, 31, 22, 9, f"Panel members\ninterviewed in 2020\nn = {fl['panel_2020']:,}")
box(26, 31, 22, 9, f"Re-interviewed\nafter 2024 election\nn = {fl['interviewed_2024_post']:,}")
box(52, 31, 22, 9, f"Reported X use\nin 2020 and 2024\nn = {fl['valid_x_both_waves']:,}")
box(78, 31, 21.5, 9, f"Twitter users\nin 2020\nn = {fl['twitter_users_2020_stayed_or_left']}", bold=True)
arrow(23, 35.5, 25.8, 35.5)
arrow(48.5, 35.5, 51.8, 35.5)
arrow(74.5, 35.5, 77.8, 35.5)
g = fl["groups_valid_x"]
ax.text(2, 25.5, f"Not compared: never used X ({g['Never']:,}); joined X by 2024 ({g['Joined']})", ha="left", va="top", fontsize=7, color=GREY)
ag = fl["analytic_groups"]
box(56, 4, 20, 10, f"Stayed\non X in 2024\nn = {ag['Stayed']}", ec=BLUE, fc="#E6F1F8", bold=True)
box(79.5, 4, 20, 10, f"Left\nnot on X in 2024\nn = {ag['Left']}", ec=VERM, fc="#FBEEE6", bold=True)
arrow(85, 30.4, 66, 14.6)
arrow(92, 30.4, 89.5, 14.6)
ax.text(2, 12.5, "Complete data on all outcomes\nand 2020 covariates:\n"
        f"n = {fl['analytic_n']} of {fl['twitter_users_2020_stayed_or_left']}", fontsize=8, va="center")
ax.text(2, 3.5, "Outcomes measured in 2020 and 2024; affective\npolarization also in 2016 (pre-trend test).", fontsize=7.5, color=GREY, va="center")
save(fig, "fig1_design_flow")

# Figure 2: who left X, by party -----------------------------------------
ex = pd.DataFrame(R["exit_by_party"]).set_index("party").loc[["Democrat", "Independent", "Republican"]]
fig, ax = plt.subplots(figsize=(W * 0.62, 2.2))
y = np.arange(len(ex))[::-1]
ax.errorbar(ex["share_left"] * 100, y, xerr=[(ex["share_left"] - ex["lo"]) * 100, (ex["hi"] - ex["share_left"]) * 100],
            fmt="s", color=VERM, ms=5, capsize=0, lw=1.2)
for yi, (pn, r_) in zip(y, ex.iterrows()):
    ax.text(r_["hi"] * 100 + 1.5, yi, f"{r_['share_left']*100:.0f}%  ({int(r_['n_left'])} of {int(r_['n'])})", va="center", fontsize=7.5)
ax.set_yticks(y, ex.index)
ax.set_xlim(0, 80)
ax.set_xlabel("2020 Twitter users who no longer used X in 2024 (%)")
ax.set_ylim(-0.6, 2.6)
save(fig, "fig2_exit_by_party")

# Figure 3: covariate balance ---------------------------------------------
bal = pd.DataFrame(R["balance"])
bal = bal.iloc[::-1].reset_index(drop=True)
fig, ax = plt.subplots(figsize=(W * 0.78, 3.6))
yy = np.arange(len(bal))
ax.axvspan(-0.1, 0.1, color="#EEEEEE", zorder=0)
ax.axvline(0, color=BLACK, lw=0.7)
ax.scatter(bal["smd_before"], yy, marker="o", facecolors="white", edgecolors=BLACK, s=22, lw=0.8, label="Survey weights only", zorder=3)
ax.scatter(bal["smd_after"], yy, marker="o", color=BLUE, s=22, label="After entropy balancing", zorder=4)
for i, r_ in bal.iterrows():
    ax.plot([r_["smd_before"], r_["smd_after"]], [i, i], color=GREY, lw=0.6, zorder=2)
ax.set_yticks(yy, bal["label"])
ax.set_xlabel("Standardized mean difference, stayers minus leavers (2020)")
ax.set_xlim(-0.45, 0.45)
ax.legend(frameon=False, loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2)
save(fig, "fig3_balance")

# Figure 4: affective polarization trajectories --------------------------
tr = pd.DataFrame(R["trajectory"])
fig, ax = plt.subplots(figsize=(W * 0.72, 3.0))
off = {"Stayed": -0.35, "Left": 0.35, "Never": 0}
ax.axvspan(2022.8, 2023.0, color=VERM, alpha=0.15, lw=0)
ax.text(2022.9, 63.5, "Ownership\nchange\n(Oct 2022)", ha="center", va="top", fontsize=7, color=VERM)
for gname in ["Never", "Left", "Stayed"]:
    t = tr[tr.group == gname].sort_values("year")
    x = t["year"] + off[gname]
    ax.errorbar(x, t["mean"], yerr=[t["mean"] - t["lo"], t["hi"] - t["mean"]], color=COL[gname], marker=MRK[gname],
                ms=4.5, lw=1.3, capsize=0, ls="--" if gname == "Never" else "-")
    last = t.iloc[-1]
    ax.text(2024.9, last["mean"], f"{ {'Stayed':'Stayed','Left':'Left','Never':'Never used'}[gname] } (n = {last['n']:,})",
            va="center", fontsize=7.5, color=COL[gname])
ax.set_xticks([2016, 2020, 2024])
ax.set_xlim(2015, 2029.5)
ax.set_ylim(30, 65)
ax.set_ylabel("Affective polarization\n(|Dem. − Rep. party thermometer|, 0–100)")
ax.spines["bottom"].set_bounds(2015, 2025)
save(fig, "fig4_trajectories")

# Figure 5: individual change in affective polarization ------------------
fig, ax = plt.subplots(figsize=(W * 0.62, 3.0))
rng = np.random.default_rng(SEED)
for i, gname in enumerate(["Stayed", "Left"]):
    ch = (A.loc[A.group == gname, "ap24"] - A.loc[A.group == gname, "ap20"]).values
    xj = i + rng.uniform(-0.18, 0.18, len(ch))
    yj = ch + rng.uniform(-0.8, 0.8, len(ch))
    ax.scatter(xj, yj, s=5, color=COL[gname], alpha=0.35, lw=0, marker=MRK[gname])
    q1, med, q3 = np.percentile(ch, [25, 50, 75])
    ax.add_patch(plt.Rectangle((i - 0.28, q1), 0.56, q3 - q1, fill=False, ec=BLACK, lw=0.9))
    ax.plot([i - 0.28, i + 0.28], [med, med], color=BLACK, lw=1.4)
    ax.plot([i], [ch.mean()], marker="D", color="white", mec=BLACK, ms=4.5, zorder=5)
    ax.text(i, 98, f"mean {ch.mean():+.1f}, median {med:+.0f}", ha="center", va="bottom", fontsize=7.5)
ax.axhline(0, color=GREY, lw=0.6, ls=":")
ax.set_xticks([0, 1], [f"Stayed\n(n = {(A.group=='Stayed').sum()})", f"Left\n(n = {(A.group=='Left').sum()})"])
ax.set_xlim(-0.6, 1.6)
ax.set_ylim(-108, 112)
ax.set_ylabel("Change in affective polarization,\n2020 to 2024 (thermometer points)")
save(fig, "fig5_individual_change")

# Figure 6: main estimates ------------------------------------------------
est = pd.DataFrame(R["estimates"])
order = ["ap", "mis", "ang", "tru"]
labs = {"ap": "Affective\npolarization", "mis": "Confident\nmisperception", "ang": "Anger about\nthe country", "tru": "Trust in\nnews media"}
specs = [("Lagged outcome", "Survey + entropy-balancing weights", "Lagged outcome, balanced (primary)", BLUE, "o"),
         ("Change score", "Survey + entropy-balancing weights", "Change score, balanced", BLACK, "s"),
         ("Lagged outcome", "Survey weights", "Lagged outcome, survey weights only", GREY, "^"),
         ("Lagged outcome", "Unweighted", "Lagged outcome, unweighted", GREY, "v")]
fig, ax = plt.subplots(figsize=(W, 3.1))
for j, (m, w, lab, c, mk) in enumerate(specs):
    for i, k in enumerate(order):
        r_ = est[(est.outcome == k) & (est.model == m) & (est.weights == w)].iloc[0]
        x = i + (j - 1.5) * 0.17
        ax.errorbar(x, r_["b_std"], yerr=[[r_["b_std"] - r_["lo_std"]], [r_["hi_std"] - r_["b_std"]]], fmt=mk, color=c,
                    mfc=c if j < 2 else "white", ms=4.5, lw=1.1, label=lab if i == 0 else None)
    if j == 0:
        for i, k in enumerate(order):
            r_ = est[(est.outcome == k) & (est.model == m) & (est.weights == w)].iloc[0]
            ax.text(i, -0.7, f"Holm p = {r_['p_holm']:.3f}", fontsize=7, color=BLUE, ha="center")
ax.axhline(0, color=BLACK, lw=0.7)
ax.set_xticks(range(4), [labs[k] for k in order])
ax.set_ylabel("Stayed minus left, 2020→2024\n(SD of 2020 outcome)")
ax.set_ylim(-0.78, 0.6)
ax.legend(frameon=False, ncol=2, loc="upper center", bbox_to_anchor=(0.5, -0.2))
save(fig, "fig6_main_estimates")

# Figure 7: by party ------------------------------------------------------
sp = pd.DataFrame(R["party_split"])
inter = sp[sp.party == "Interaction"].set_index("outcome")
sp = sp[sp.party != "Interaction"]
fig, ax = plt.subplots(figsize=(W, 2.9))
pc = {"Democrat": ("#56B4E9", "o"), "Republican": ("#CC79A7", "s")}
for j, pn in enumerate(["Democrat", "Republican"]):
    for i, k in enumerate(order):
        r_ = sp[(sp.outcome == k) & (sp.party == pn)].iloc[0]
        x = i + (j - 0.5) * 0.24
        c, mk = pc[pn]
        ax.errorbar(x, r_["b_std"], yerr=[[r_["b_std"] - r_["lo_std"]], [r_["hi_std"] - r_["b_std"]]], fmt=mk, color=c, ms=5, lw=1.2,
                    label=f"{pn}s (stayed n = {int(r_['n_stayed'])}, left n = {int(r_['n_left'])})" if i == 0 else None)
for i, k in enumerate(order):
    ax.text(i, -0.78, f"difference p = {inter.loc[k, 'p']:.2f}", ha="center", fontsize=7, color=GREY)
ax.axhline(0, color=BLACK, lw=0.7)
ax.set_xticks(range(4), [labs[k] for k in order])
ax.set_ylabel("Stayed minus left, 2020→2024\n(SD of 2020 outcome)")
ax.set_ylim(-0.85, 0.65)
ax.legend(frameon=False, ncol=2, loc="upper center", bbox_to_anchor=(0.5, -0.2))
save(fig, "fig7_by_party")
print("[s04] wrote 7 figures (PDF + PNG)")
